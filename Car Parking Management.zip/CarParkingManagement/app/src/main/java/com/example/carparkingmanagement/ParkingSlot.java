package com.example.carparkingmanagement;

public class ParkingSlot {
    private int slotNumber;
    private boolean isOccupied;
    private String plateNumber;
    private String occupiedBy; // UserID of the person who parked

    // Empty constructor required for Firestore
    public ParkingSlot() {}

    public ParkingSlot(int slotNumber) {
        this.slotNumber = slotNumber;
        this.isOccupied = false;
        this.plateNumber = "";
        this.occupiedBy = "";
    }

    // Getters
    public int getSlotNumber() { return slotNumber; }
    public boolean isOccupied() { return isOccupied; }
    public String getPlateNumber() { return plateNumber; }
    public String getOccupiedBy() { return occupiedBy; }

    // Setters
    public void setSlotNumber(int slotNumber) { this.slotNumber = slotNumber; }
    public void setOccupied(boolean occupied) { isOccupied = occupied; }
    public void setPlateNumber(String plateNumber) { this.plateNumber = plateNumber; }
    public void setOccupiedBy(String occupiedBy) { this.occupiedBy = occupiedBy; }
}