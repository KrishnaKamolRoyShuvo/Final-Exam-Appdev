package com.example.carparkingmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class UserDashboardActivity extends AppCompatActivity {

    private GridView parkingGridView;
    private Button unparkButton, logoutButton;
    private SlotAdapter slotAdapter;
    private List<ParkingSlot> parkingSlots = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String userParkedSlotId = null;
    private double pricePerHour = 5.0; // Default price

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        parkingGridView = findViewById(R.id.parkingGridView);
        unparkButton = findViewById(R.id.unparkButton);
        logoutButton = findViewById(R.id.logoutButton);
        slotAdapter = new SlotAdapter(this, parkingSlots);
        parkingGridView.setAdapter(slotAdapter);

        fetchParkingPrice();
        loadParkingSlots();
        setupListeners();

        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(UserDashboardActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void fetchParkingPrice() {
        db.collection("parking_config").document("settings").get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        Double price = documentSnapshot.getDouble("pricePerHour");
                        if (price != null) {
                            pricePerHour = price;
                        }
                    }
                });
    }

    private void loadParkingSlots() {
        db.collection("parking_slots").orderBy("slotNumber").addSnapshotListener((snapshots, e) -> {
            if (e != null) { return; }
            parkingSlots.clear();
            userParkedSlotId = null;
            if (mAuth.getCurrentUser() == null) return; // Exit if user is logged out
            String currentUserId = mAuth.getCurrentUser().getUid();
            for (QueryDocumentSnapshot doc : snapshots) {
                ParkingSlot slot = doc.toObject(ParkingSlot.class);
                parkingSlots.add(slot);
                if (slot.isOccupied() && currentUserId.equals(slot.getOccupiedBy())) {
                    userParkedSlotId = doc.getId();
                }
            }
            slotAdapter.notifyDataSetChanged();
            updateUnparkButtonVisibility();
        });
    }

    private void setupListeners() {
        parkingGridView.setOnItemClickListener((parent, view, position, id) -> {
            ParkingSlot selectedSlot = parkingSlots.get(position);
            if (selectedSlot.isOccupied()) {
                Toast.makeText(this, "This slot is already occupied.", Toast.LENGTH_SHORT).show();
            } else {
                showBookingDialog(selectedSlot);
            }
        });

        unparkButton.setOnClickListener(v -> showUnparkConfirmation());
    }

    private void showBookingDialog(ParkingSlot slot) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Book Slot " + slot.getSlotNumber());

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_book_slot, null);
        final EditText plateEditText = view.findViewById(R.id.plateEditText);
        final EditText hoursEditText = view.findViewById(R.id.hoursEditText);
        builder.setView(view);

        builder.setPositiveButton("Pay with COD", (dialog, which) -> {
            String plateNumber = plateEditText.getText().toString().trim().toUpperCase();
            String hoursStr = hoursEditText.getText().toString().trim();

            if (TextUtils.isEmpty(plateNumber) || TextUtils.isEmpty(hoursStr)) {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                int hours = Integer.parseInt(hoursStr);
                if (hours <= 0) {
                    Toast.makeText(this, "Hours must be greater than 0.", Toast.LENGTH_SHORT).show();
                    return;
                }
                bookSlot(slot, plateNumber, hours);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number for hours.", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void bookSlot(ParkingSlot slot, String plateNumber, int hours) {
        String userId = mAuth.getCurrentUser().getUid();
        DocumentReference slotRef = db.collection("parking_slots").document("slot_" + slot.getSlotNumber());

        Map<String, Object> updates = new HashMap<>();
        updates.put("occupied", true);
        updates.put("plateNumber", plateNumber);
        updates.put("occupiedBy", userId);
        updates.put("hours", hours);

        slotRef.update(updates)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Slot booked successfully!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Booking failed.", Toast.LENGTH_SHORT).show());
    }

    private void showUnparkConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Unpark Vehicle")
                .setMessage("Are you sure you want to unpark? This will complete the transaction.")
                .setPositiveButton("Yes, Unpark", (dialog, which) -> unparkVehicle())
                .setNegativeButton("No", null)
                .show();
    }

    private void unparkVehicle() {
        if (userParkedSlotId == null) return;

        DocumentReference slotRef = db.collection("parking_slots").document(userParkedSlotId);
        slotRef.get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot == null || !documentSnapshot.exists()) return;

            Long hours = documentSnapshot.getLong("hours");
            if (hours == null) hours = 1L;

            double cost = hours * pricePerHour;

            WriteBatch batch = db.batch();

            DocumentReference incomeRef = db.collection("parking_config").document("income");
            batch.update(incomeRef, "totalRevenue", FieldValue.increment(cost));

            batch.update(slotRef, "occupied", false, "plateNumber", "", "occupiedBy", "", "hours", 0);

            batch.commit()
                    .addOnSuccessListener(aVoid -> Toast.makeText(this, String.format("Vehicle unparked. Cost: $%.2f", cost), Toast.LENGTH_LONG).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "Unparking failed.", Toast.LENGTH_SHORT).show());
        });
    }

    private void updateUnparkButtonVisibility() {
        if (userParkedSlotId != null) {
            unparkButton.setVisibility(View.VISIBLE);
        } else {
            unparkButton.setVisibility(View.GONE);
        }
    }
}