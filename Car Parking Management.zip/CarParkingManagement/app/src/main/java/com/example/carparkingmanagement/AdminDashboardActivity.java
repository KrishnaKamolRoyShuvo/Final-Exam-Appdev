package com.example.carparkingmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {

    private GridView parkingGridView;
    private Button initializeSlotsButton, setPriceButton, logoutButton;
    private TextView totalIncomeTextView;
    private SlotAdapter slotAdapter;
    private List<ParkingSlot> parkingSlots = new ArrayList<>();
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        db = FirebaseFirestore.getInstance();
        parkingGridView = findViewById(R.id.parkingGridViewAdmin);
        initializeSlotsButton = findViewById(R.id.initializeSlotsButton);
        setPriceButton = findViewById(R.id.setPriceButton);
        logoutButton = findViewById(R.id.logoutButton);
        totalIncomeTextView = findViewById(R.id.totalIncomeTextView);
        slotAdapter = new SlotAdapter(this, parkingSlots);
        parkingGridView.setAdapter(slotAdapter);

        loadParkingSlots();
        loadTotalIncome();

        initializeSlotsButton.setOnClickListener(v -> showInitializeDialog());
        setPriceButton.setOnClickListener(v -> showSetPriceDialog());

        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        parkingGridView.setOnItemClickListener((parent, view, position, id) -> {
            ParkingSlot selectedSlot = parkingSlots.get(position);
            showAdminSlotDialog(selectedSlot);
        });
    }

    private void loadTotalIncome() {
        db.collection("parking_config").document("income")
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) { return; }
                    if (snapshot != null && snapshot.exists()) {
                        Number totalRevenue = snapshot.getDouble("totalRevenue");
                        if (totalRevenue != null) {
                            totalIncomeTextView.setText(String.format("Total Income: $%.2f", totalRevenue.doubleValue()));
                        }
                    } else {
                        totalIncomeTextView.setText("Total Income: $0.00");
                    }
                });
    }

    private void loadParkingSlots() {
        db.collection("parking_slots").orderBy("slotNumber").addSnapshotListener((snapshots, e) -> {
            if (e != null) {
                Toast.makeText(this, "Error loading slots", Toast.LENGTH_SHORT).show();
                return;
            }
            parkingSlots.clear();
            for (QueryDocumentSnapshot doc : snapshots) {
                parkingSlots.add(doc.toObject(ParkingSlot.class));
            }
            slotAdapter.notifyDataSetChanged();
        });
    }

    private void showInitializeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Number of Slots");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("e.g., 10");
        builder.setView(input);

        builder.setPositiveButton("Set Slots", (dialog, which) -> {
            String numSlotsStr = input.getText().toString();
            try {
                int numSlots = Integer.parseInt(numSlotsStr);
                if (numSlots > 0 && numSlots <= 50) {
                    initializeSlotsInFirestore(numSlots);
                } else {
                    Toast.makeText(this, "Please enter a number between 1 and 50.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void initializeSlotsInFirestore(int numberOfSlots) {
        db.collection("parking_slots").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                WriteBatch deleteBatch = db.batch();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    deleteBatch.delete(document.getReference());
                }
                deleteBatch.commit().addOnCompleteListener(deleteTask -> {
                    if (deleteTask.isSuccessful()) {
                        WriteBatch createBatch = db.batch();
                        for (int i = 1; i <= numberOfSlots; i++) {
                            ParkingSlot slot = new ParkingSlot(i);
                            createBatch.set(db.collection("parking_slots").document("slot_" + i), slot);
                        }
                        createBatch.commit()
                                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Slots set to " + numberOfSlots, Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e -> Toast.makeText(this, "Failed to create slots", Toast.LENGTH_SHORT).show());
                    } else {
                        Toast.makeText(this, "Failed to clear old slots", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void showSetPriceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Price Per Hour");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("e.g., 5.50");
        builder.setView(input);

        builder.setPositiveButton("Set", (dialog, which) -> {
            String priceStr = input.getText().toString();
            try {
                double newPrice = Double.parseDouble(priceStr);
                db.collection("parking_config").document("settings")
                        .update("pricePerHour", newPrice)
                        .addOnSuccessListener(aVoid -> Toast.makeText(this, "Price updated successfully", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to update price", Toast.LENGTH_SHORT).show());
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid price format", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void showAdminSlotDialog(ParkingSlot slot) {
        String[] options = slot.isOccupied() ? new String[]{"View Details", "Make Available"} : new String[]{"Reserve Slot"};

        new AlertDialog.Builder(this)
                .setTitle("Slot " + slot.getSlotNumber())
                .setItems(options, (dialog, which) -> {
                    String selectedOption = options[which];
                    DocumentReference slotRef = db.collection("parking_slots").document("slot_" + slot.getSlotNumber());

                    if (selectedOption.equals("Reserve Slot")) {
                        slotRef.update("occupied", true, "plateNumber", "RESERVED", "occupiedBy", "admin");
                    } else if (selectedOption.equals("Make Available")) {
                        slotRef.update("occupied", false, "plateNumber", "", "occupiedBy", "");
                    } else if (selectedOption.equals("View Details")) {
                        new AlertDialog.Builder(this)
                                .setTitle("Slot Details")
                                .setMessage("Plate: " + slot.getPlateNumber() + "\nUser ID: " + slot.getOccupiedBy())
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .show();
    }
}