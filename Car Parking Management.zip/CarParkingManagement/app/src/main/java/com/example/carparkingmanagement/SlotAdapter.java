package com.example.carparkingmanagement;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import java.util.List;

public class SlotAdapter extends ArrayAdapter<ParkingSlot> {

    public SlotAdapter(Context context, List<ParkingSlot> slots) {
        super(context, 0, slots);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ParkingSlot slot = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item_slot, parent, false);
        }

        LinearLayout slotLayout = convertView.findViewById(R.id.slot_layout);
        TextView slotNumberText = convertView.findViewById(R.id.slot_number_text);
        TextView plateNumberText = convertView.findViewById(R.id.plate_number_text);

        slotNumberText.setText("Slot " + slot.getSlotNumber());

        if (slot.isOccupied()) {
            slotLayout.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.slot_occupied));
            plateNumberText.setText(slot.getPlateNumber());
        } else {
            slotLayout.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.slot_available));
            plateNumberText.setText("Available");
        }
        return convertView;
    }
}